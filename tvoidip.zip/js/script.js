$(document).ready(function(){
  $('.slider').slick({




    infinite: true,
    speed: 500,
    // fade: true,
    cssEase: 'linear'
  });
});